const CACHE = 'the-field-v7';
const ASSETS = ['/', '/index.html', '/logo.svg', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  // Always network first for HTML — never serve stale app shell
  if(e.request.mode === 'navigate' || e.request.url.includes('index.html')){
    e.respondWith(fetch(e.request).catch(() => caches.match('/index.html')));
    return;
  }
  // Network first for API calls
  if(e.request.url.includes('supabase') || e.request.url.includes('espn')){
    e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
    return;
  }
  // Cache first for static assets
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(resp => {
      const clone = resp.clone();
      caches.open(CACHE).then(c => c.put(e.request, clone));
      return resp;
    }))
  );
});
